<div class="page-wrapper">
<div class="gamemonetize-main pull-right span79">
	<div class="gamemonetize-main-headself">
		<i class="fa fa-navicon"></i>
	</div>
	<div class="gamemonetize-main-content">
        {{SETTING_PAGE_CONTENT}}
	</div>
</div>

<div class="gamemonetize-nav pull-left span20">
    <div class="gamemonetize-nav-headself">@configuration@</div>
    {{SETTING_NAVIGATION_MENU}}
</div>
</div>