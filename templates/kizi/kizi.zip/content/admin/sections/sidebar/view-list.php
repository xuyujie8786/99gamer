<li class="__mc-{{VIEW_SIDEBAR_ID}} g-d5 _j4 categories-item">
	<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-name">{{VIEW_SIDEBAR_NAME}}</div>
	<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-type">{{VIEW_SIDEBAR_TYPE}}</div>
	<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-category-tags">{{VIEW_SIDEBAR_CATEGORY_TAGS}}</div>
	<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-custom-link">{{VIEW_SIDEBAR_CUSTOM_LINK}}</div>
	<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-icon">{{VIEW_SIDEBAR_ICON}}</div>
	<div style="text-align: left;float: left;flex:1;margin-left:20px" class="_slider-category-tags">{{VIEW_SIDEBAR_ORDERING}}</div>
	<div>
		<button data-href="{{CONFIG_SITE_URL}}/admin/sidebar/edit/{{VIEW_SIDEBAR_ID}}" class="btn-p btn-small btn-p2 fa fa-pencil"></button>
		{{VIEW_SIDEBAR_BUTTON_DELETE}}
	</div>
</li>