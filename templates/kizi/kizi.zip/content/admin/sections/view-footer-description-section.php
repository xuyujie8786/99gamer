<div class="general-box _0e4">
	<ul class="categories-list scroll-custom">
		{{VIEW_FOOTER_DESCRIPTION_LIST}}
	</ul>
</div>