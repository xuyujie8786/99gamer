<script language="javascript">var PageType ="{{NEW_GAME_PAGE}}"; var ids ="{{NEW_GAME_IDS}}";</script>

<div id="Gameinner" class="bgs">
    <div class="partners fn-clear">
        <p class="blog-big">BLOG</p>
        {{BLOGS_LIST}}

        <a class="blog-load-more">Load more..</a>
    </div>
    <dl class="bottomtext fn-clear" style="padding:20px;">
        {{FOOTER_DESCRIPTION}}
    </dl>
</div>

{{FOOTER_CONTENT}}