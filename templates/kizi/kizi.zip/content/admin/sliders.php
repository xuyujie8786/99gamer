<div class="gamemonetize-main-headself">
	<i class="fa fa-bookmark"></i> Manage Sliders
</div>
{{SLIDERS_SECTION_CONTENT}}