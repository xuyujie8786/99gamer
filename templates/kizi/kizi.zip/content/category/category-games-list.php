<div class="post">
    <a href="{{CATEGORY_GAME_URL}}" class="game-item">
        <img src="{{CATEGORY_GAME_IMAGE}}" alt="{{CATEGORY_GAME_NAME}}">
        <p class="post-name" data-url="{{CATEGORY_GAME_VIDEO_URL}}" data-scale="1.2" data-translate="-23px,-25px">{{CATEGORY_GAME_NAME}}</p>
        <span class="featured_icon"></span>
    </a>
</div>