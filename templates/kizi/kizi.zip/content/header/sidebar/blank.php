<a href="#" class="sidebar-item no-hover no-link">
    <div class="sidebar-item-icon">&nbsp;</div>
    <div class="sidebar-item-title">&nbsp;</div>
</a>
<a href="#" class="sidebar-item no-hover no-link">
    <div class="sidebar-item-icon">&nbsp;</div>
    <div class="sidebar-item-title">&nbsp;</div>
</a>
<a href="#" class="sidebar-item no-hover no-link">
    <div class="sidebar-item-icon">&nbsp;</div>
    <div class="sidebar-item-title">&nbsp;</div>
</a>
<a href="#" class="sidebar-item no-hover no-link">
    <div class="sidebar-item-icon">&nbsp;</div>
    <div class="sidebar-item-title">&nbsp;</div>
</a>