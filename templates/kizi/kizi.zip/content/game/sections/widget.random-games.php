
	    <ul class="common-game-style bot-similar-games">
			{{WIDGET_SIDEBAR_RANDOM_LIST}}
		</ul>