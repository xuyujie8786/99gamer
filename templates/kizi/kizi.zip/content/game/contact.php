<div id="Pages" class="bgs">
    {{FOOTER_DESCRIPTION_CONTENT_VALUE}}
    <dl class="bgs bottomtext fn-clear" style="padding:20px;">    
        {{FOOTER_DESCRIPTION}}
    </dl>
    <a href="https://gamemonetize.com" target="_blank" aria-label="GameMonetize.com CMS" style="display: block;text-align: center;padding-top: 20px;">
        <img src="https://api.gamemonetize.com/powered_by_gamemonetize.png" alt="GameMonetize.com CMS" style="width:290px;text-align: center;margin: 0 auto;">
    </a>
</div>