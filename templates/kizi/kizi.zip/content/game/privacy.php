<div id="Pages" class="bgs">
    {{FOOTER_DESCRIPTION_CONTENT_VALUE}}
    <dl class="bgs bottomtext fn-clear" style="padding:20px;">    
        {{FOOTER_DESCRIPTION}}
    </dl>
</div>