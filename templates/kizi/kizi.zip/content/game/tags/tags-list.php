<li>
    <a href="{{TAGS_URL}}">{{TAGS_NAME}}</a>
</li>