<script language="javascript">var PageType ="{{NEW_GAME_PAGE}}"; var ids ="{{NEW_GAME_IDS}}";</script>

<div id="Gameinner" class="bgs">
    <div class="blog-post-title">{{BLOG_TITLE}}</div>
    <div class="blog-post-date">Posted on {{BLOG_DATE_CREATED}}</div>
    <hr style="margin: 10px;">
    <div class="blog-post-post">{{BLOG_POST}}</div>
    <div class="blog-post-bottom"></div>
</div>

{{FOOTER_CONTENT}}