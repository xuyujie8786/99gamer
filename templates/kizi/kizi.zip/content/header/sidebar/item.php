<a href="{{HEADER_SIDEBAR_URL}}" class="sidebar-item" target="{{HEADER_SIDEBAR_TARGET}}">
    <div class="sidebar-item-icon">
        <i class="material-icons-outlined material-symbols-outlined" style="margin-right: 1rem;">{{HEADER_SIDEBAR_ICON}}</i>
    </div>
    <div class="sidebar-item-title">{{HEADER_SIDEBAR_NAME}}</div>
</a>