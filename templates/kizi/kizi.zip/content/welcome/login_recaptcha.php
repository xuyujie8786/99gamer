<div class="vByg5">
	<div class="g-recaptcha" data-sitekey="{{RECAPTCHA_SITE_KEY}}"></div>
</div>