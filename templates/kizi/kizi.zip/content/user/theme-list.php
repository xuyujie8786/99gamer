<label>
	<li id="theme-check" data-theme-id="{{SETTING_THEME_ID}}" class="_theme-viewbox {{SETTING_THEME_ACTIVE_CLASS}} theme-chk-{{SETTING_THEME_ID}}">
	    <div class="_theme-box-item {{SETTING_THEME_CLASS}} _a-c">
	        {{SETTING_THEME_NUMBER}}
	    </div>
	    <input class="hidden" type="radio" name="theme_pilot" value="{{SETTING_THEME_ID}}" {{SETTING_THEME_CHECKED}}>
	</li>
</label>