<li>
    <a href="{{CATEGORY_URL}}" class="">{{CATEGORY_NAME}}<span>({{CATEGORY_NUMBER}})</span></a>
</li>