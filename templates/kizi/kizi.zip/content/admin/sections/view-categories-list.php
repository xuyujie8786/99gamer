<li class="__mc-{{VIEW_CATEGORY_ID}} g-d5 _j4 categories-item">
<div class="gameicon" style="width:40px;height:40px;border-radius: 50%;background-image: url({{VIEW_CATEGORY_IMAGE}});background-size: cover;background-position-x: 50%;background-position-y: 50%;"></div>
	<div style="text-align: left;float-left;flex:1;margin-left:20px" class="_category-name">{{VIEW_CATEGORY_NAME}}</div>
	<div>
		<button data-href="{{CONFIG_SITE_URL}}/admin/categories/edit/{{VIEW_CATEGORY_ID}}" class="btn-p btn-small btn-p2 fa fa-pencil"></button>
		{{VIEW_CATEGORY_BUTTON_DELETE}}
	</div>
</li>