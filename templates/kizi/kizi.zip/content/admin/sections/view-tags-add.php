<div class="general-box _0e4">
	<div class="header-box">
		<i class="fa fa-plus color-w icon-middle"></i>
	</div>
	<div class="_5e4">
		<form id="addtags-form" enctype="multipart/form-data">
			<div class="vByg5">
				<input type="text" name="ac_name" placeholder="@tags_name@">
			</div>
			<div class="" style="margin-top: 10px;">
				<label for="">Footer Description</label>
				<textarea name="ac_footer_description" placeholder="footer description" rows="15" style="min-height: 339px;" class="editor-js _text-input _tr5 tinymce">
				</textarea>
			</div>
			<button type="submit"  id="addtags-btn" class="btn-p btn-p1">
				<i class="fa fa-plus icon-middle"></i>
				@add@
			</button>
		</form>
	</div>
</div>