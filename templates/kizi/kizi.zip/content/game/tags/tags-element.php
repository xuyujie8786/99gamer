<span class="pl game-title" style="font-size: 25px !important;color:white;margin-bottom:5px;">@tags@</span>
<ul>
    {{TAGS_LIST}}
</ul>