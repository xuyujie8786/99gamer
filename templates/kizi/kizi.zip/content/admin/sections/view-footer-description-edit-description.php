<div>
	<div style="margin-bottom: 10px;">
		Description
	</div>
	<div>
		<textarea rows="15" style="min-height: 339px;" name="footer_description" class="editor-js _text-input _tr5 tinymce">{{EDIT_FOOTER_DESCRIPTION_VALUE}}</textarea>
		<p>
			<button class="btn-p btn-p1 rewriteTextFooter" type="button">Rewrite</button>
			<button class="btn-p btn-p1 clickToCopyText" type="button" data-text="{{CHAT_GPT_TEMPLATE_FOOTER}}">Copy Rewrite Prompt</button>
		</p>
	</div>
</div>