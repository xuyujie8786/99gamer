  <li>
      <a href="{{WIDGET_TOPSTAR_URL}}" class="game-item">
          <img src="{{WIDGET_TOPSTAR_IMAGE}}">
          <p class="post-name" data-url="{{WIDGET_TOPSTAR_VIDEO_URL}}" data-scale="1.2" data-translate="-43.5px,-38px">{{WIDGET_TOPSTAR_NAME}}</p>
      </a>
  </li>