 <a href="{{TAGS_URL}}" class="taglink">
     <div class="tag">
         <!-- <div class="tagpic fn-left">
             <img src="{{TAGS_THUMB}}" alt="{{TAGS_NAME}}">
         </div> -->
         <div class="taginfo fn-left">
             <p class="pl">{{TAGS_NAME}}</p>
             <p class="num">{{TAGS_NUMBER}} Games</p>
         </div>
     </div>
 </a>