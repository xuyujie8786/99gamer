<a href="{{HEADER_SIDEBAR_URL}}" class="sidebar-item ">
    <hr class="separator">
</a>