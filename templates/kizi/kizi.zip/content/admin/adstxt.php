<div class="gamemonetize-main-headself">
	<i class="fa fa-flag-o"></i>
</div>
<div class="general-box _yt10 _yb10 _0e4">
	<form id="adsTxtArea-form" method="POST">
		<div class="g-d5" style="display: block;">

			<div class="r05-t _b-r _5e4">
				<span class="_f12">Ads.txt file</span>
				<textarea style="height:383px;" class="b-input scroll-custom" name="adstxt">{{ADS_TXT}}</textarea>
			</div>
		</div>
		<div class="_a-r _5e4 _b-t">
			<button type="submit" class="btn-p btn-p1">
				<i class="fa fa-check icon-middle"></i>
				@save@
			</button>
		</div>
	</form>
</div>