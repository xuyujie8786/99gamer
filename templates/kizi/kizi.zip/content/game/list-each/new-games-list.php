<div class="post">
    <a href="{{NEW_GAME_URL}}" class="game-item">
        <img src="{{NEW_GAME_IMAGE}}" alt="{{NEW_GAME_NAME}}">
        <p class="post-name" data-url="{{NEW_GAME_VIDEO_URL}}" data-scale="1.2" data-translate="-23px,-25px">{{NEW_GAME_NAME}}</p>
        {{NEW_GAME_FEATURED}}

        {{NEW_GAMES_ICON}}
    </a>
</div>